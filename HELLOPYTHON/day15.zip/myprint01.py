print("hello", end=",")
print("hello")

print()