arr = ["홍길동", "전우치", "임꺽정"]

for i, item in enumerate(arr):
    print(i, item)
